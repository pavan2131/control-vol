# Automatic-Volume-Control-System

---

1. A minor project built using **Arduino Board , Ultrasonic sensor and python** .
   1. Using all the above components , volume of the computer / pc / laptops can be controlled and automated depending on the distance between the user and the system.

   2. Ultrasonic sensor is used to measure the distance between the user and the computer and then this distance measured is further transferred to Arduino board for     processing.

   3. The Python language was used to process the data received from Arduino and manipulate volume operations in one's operating system using libraries like "pyserial" ,   "pycaw" and others...**:)**

---

